from __future__ import unicode_literals

from django.db import models
import re
# Create your models here.
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')

class UserManager(models.Manager):
    def validate(self, post_data):
        errors = {}


        #check for empty field
        for field, value in post_data.iteritems():
            if len(value) < 1:
                errors[field] = "{} field is required".format(field.replace('_', ''))

        #check for valid EMAIL_REGEX
        if field == "first_name" or field == "last_name":
            if not field in errors and len(value) < 5:
                errors[field] = "{} field must be at least 5 char".format(field.replace('_', ''))

        #check for that good EMAIL_REGEX
        if not "email" in errors and not re.match(EMAIL_REGEX, post_data['email']):
            errors['email'] = "invalid email"

        else:
            if len(self.filter(email=post_data['email'])) > 1:
                errors['email'] = "email taken"

        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 255)
    last_name = models.CharField(max_length = 255)
    email = models.EmailField(unique=True)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now_add = True)
    objects = UserManager()
    def __str__(self):
        return self.email
